# UniCou Pakistan — Website Starter

A responsive single-page website for UniCou Pakistan with:
- University listing cards
- Student enquiry/application form
- WhatsApp message handoff
- Sample testimonial cards (replace with genuine, approved reviews)
- Demo admin dashboard with local-browser enquiry records and CSV export

## Important before publishing
1. Open `index.html` in a text editor.
2. Search for `WHATSAPP_NUMBER` near the bottom and replace `923001234567` with your real WhatsApp number in international digits-only format. For example, a Pakistani number like `0300 1234567` becomes `923001234567`.
3. Change `ADMIN_DEMO_PASSWORD` from `ChangeMe123!`.
4. Replace the sample testimonials with genuine reviews you have permission to publish, or remove that section.
5. Confirm all university information, fees, program availability and requirements from official university sources.
6. Add your real contact details, privacy notice and any legal/business details you need.

## GitHub: upload the website
1. Open your repository: `https://github.com/ahsan alvi895-oss/unicou` (if this URL doesn't open, use your GitHub account and select the `unicou` repository).
2. Click **Code** to return to the repository's file list.
3. Click **Add file** → **Upload files**.
4. Extract this ZIP on your computer first.
5. Drag `index.html` into the upload area. You can also upload `README.md`.
6. In the commit box, write `Add UniCou Pakistan website`.
7. Choose **Commit directly to the main branch** and click **Commit changes**.
8. To publish: open **Settings** → **Pages**. Under Build and deployment, select **Deploy from a branch**. Select branch `main` and folder `/(root)`, then click **Save**.
9. Wait a few minutes and refresh the Pages section. GitHub will show your live website link there.

If your existing repository already has an `index.html`, uploading this file will replace its contents after you confirm the commit. Keep a backup if you need the old file.

## Admin dashboard demo
- Visit your website and click **Admin dashboard** in the footer.
- Demo password: `ChangeMe123!` (change it in the source).
- Enquiries submitted in this browser are stored in that browser's `localStorage` and can be exported as CSV.
- This is NOT a secure production admin system. Browser-only passwords and localStorage are not secure, do not synchronise between devices, and will not collect WhatsApp submissions. For real student applications, use a backend/database, server-side authentication, access controls, HTTPS, a privacy notice and a secure retention policy.

## Notes
This is a front-end starter, not a complete secure admissions CRM. The form opens WhatsApp so the student can review and send their enquiry. No email or server submission happens automatically.
